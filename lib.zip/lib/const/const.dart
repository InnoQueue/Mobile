export 'endpoints.dart';
export 'variable_constants.dart';
export 'colors.dart';
export 'text_theme.dart';
export 'appres.dart';
