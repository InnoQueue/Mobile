const kTasksEndpoint = "tasks";
const kQueuesEndpoint = "queues";
const kNotificationsEndpoint = "notifications";
const kSettingsEndpoint = "settings";
const kQueueDetailsEndpoint = "queue-details";
