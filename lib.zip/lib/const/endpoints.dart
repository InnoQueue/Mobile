const kTasksEndpoint = "tasks";
const kQueuesEndpoint = "queues";
const kNotificationsEndpoint = "notifications";
const kSettingsEndpoint = "settings";
const kQueueDetailsEndpoint = "queue-details";
const kNotificationSettingsEndpoint = "notification-settings";
const kThemeSettingsEndpoint = "theme-settings";
const kLangaugeSettingsEndpoint = "langage-settings";
