const tileHeight = 70.0;

const queueDetailsPadding = 15.0;
