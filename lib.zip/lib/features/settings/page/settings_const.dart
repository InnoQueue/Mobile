class SettingsRes {
  static const List<String> notificationLabels = [
    "n1",
    "n2",
    "n3",
    "n4",
    "n5",
    "n6",
  ];
}
