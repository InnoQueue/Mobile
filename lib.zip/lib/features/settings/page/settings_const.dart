class SettingsRes {
  static const List<String> notificationLabels = [
    "Notify when someone completed a task",
    "Notify when someone skipped a task",
    "Notify when someone joined a queue",
    "Notify when someone temporarily left a queue",
    "Notify when someone left a queue",
  ];
}
