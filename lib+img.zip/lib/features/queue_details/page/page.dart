export 'queue_details_page.dart';
