// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pincode_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_PincodeModel _$$_PincodeModelFromJson(Map<String, dynamic> json) =>
    _$_PincodeModel(
      pincode: json['pin_code'] as String,
      qrcode: json['qr_code'] as String,
    );

Map<String, dynamic> _$$_PincodeModelToJson(_$_PincodeModel instance) =>
    <String, dynamic>{
      'pin_code': instance.pincode,
      'qr_code': instance.qrcode,
    };
